c
c $Id: implicit.h,v 1.1 1997/12/24 23:11:47 rosinski Exp $
c $Author: rosinski $
c
      implicit none
 
