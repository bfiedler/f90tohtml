c
c $Id: perturb.h,v 1.1 1998/04/01 07:11:51 ccm Exp $
c $Author: ccm $
c
      common/perturb/pertlim
      real pertlim  ! Bound for rectangular distribution of perturbation
c
 
