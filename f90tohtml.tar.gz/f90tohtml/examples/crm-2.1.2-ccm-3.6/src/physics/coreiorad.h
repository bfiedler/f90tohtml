c
c $Id: coreiorad.h,v 1.1 1998/04/01 07:21:35 ccm Exp $
c $Author: ccm $
c
      common/coreiorad/pbigbufc
      pointer (pbigbufc,bigbufc)
      real bigbufc(plngbuf,beglat:endlat)
C
 
