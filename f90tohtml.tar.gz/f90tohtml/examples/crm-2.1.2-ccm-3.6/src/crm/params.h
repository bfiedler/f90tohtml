c     $Header: /fs/cgd/csm/models/CVS.REPOS/atm/ccm_crm_src/crm/Attic/params.h,v 1.1.2.1 1998/08/11 19:20:30 zender Exp $  -*-fortran-*-

#ifndef PARAMS_SET
#define PARAMS_SET

c     There is only one C preprocessor token particular to the CRM:
c     CRM_SRB token, true by default, serves to isolate SRB code
#define CRM_SRB 1

#define PCNST 1
#define PNATS 0
#define PLEV 18
#define PLEVR 18
#define POZLEV 23

#define PLON 1
#define PLAT 1
#define PTRM 1
#define PTRN 1
#define PTRK 1

#endif /* PARAMS_SET */





