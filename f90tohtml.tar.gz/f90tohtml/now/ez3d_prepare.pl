#!/usr/bin/perl
#6 April 2009
#change the following ABSOLUTE PATH to your CRM directory
$the_path="/home/bfiedler/f90tohtml/now/ez3dsource/";

-e $the_path || die ("$the_path not set right");

$outdir="ez3d_ls"; #relative path to output directory
mkdir($outdir,0755) if (! -e $outdir);


@the_dirs=("");

$the_files="*.[fF]";
foreach $dir (@the_dirs){
	@split_dir=split /\//,$dir;
	$title=pop @split_dir;
	if ($title eq "") { $title="main"};
	$file_name="$outdir/".$title.".ls";
	$ls_opt=$the_path.$dir.$the_files;
	print "\npreparing $file_name\n\t from $ls_opt\n";
	system "ls $ls_opt >$file_name " || die ("cannot write $file_name \n");
}
$file_name="$outdir/include.ls";
unlink($file_name) || warn ("cannot unlink $file_name");
$the_files="*.common";
foreach $dir (@the_dirs){
	$ls_opt=$the_path.$dir.$the_files;
	print "\nappending to $file_name\n\t from $ls_opt\n";
	system "ls $ls_opt >>$file_name " || die ("darn, no write $file_name \n");
}
print "DONE\nNow try typing f90tohtml ez3d.f2h\n";

